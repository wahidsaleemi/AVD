<# 
.Synopsis
Powershell script that enables inbox SxSStack to be used for reverse connect (for versions starting from RS4)
.Description
Creates a new registry and copies the full content in registery RDP-Tcp.
On top the contents copied, two additional fields are created for the new registery.
Then create a listener for the new registry so that an Inbox SxS Stack can be used for ReverseConnect.
.Parameter SxSStackVersionName
Optional
The name of the new registery created.
If not used the scripts assigns a default value to this parameter.
.Example
User needs to run this script with admin privileges since we are editing and creating the registery values.
.\enablesxsstackrc.ps1
#>

#This parameter will be taken as commandline parameter.
Param(
    [string]$SxSStackVersionName
)

#Checking the OSVersion number extracted from version string to determine whether the current OS is before or after RS4.
$RS4Version = "10.0.17083"
if([System.Environment]::OSVersion.VersionString.Split(" ")[[System.Environment]::OSVersion.VersionString.Split(" ").Length-1] -lt $RS4Version){
    Write-Error "Please use the MSI for the current OS version."
    throw
}

#Helper function to recursively traverse and add folders existing under RDP-Tcp
function addChildFolder($children, $destination){
    foreach($child in $children){
        $names = $child.Name.Split('\')
        if(-not ($names.Count -gt 0)){
            Write-Error "Child Name format is invalid"
            throw
        }
        $newDestination = $destination+ '\' + $names[$names.Count-1] 
        
        New-Item -ItemType Directory -Force -Path $newDestination

        $message = "Created directory for "+$names[$names.Count-1]
        Write-Output $message

        $existingFolder = $child.Name -replace "HKEY_LOCAL_MACHINE", "HKLM:"

        $childRegistry = Get-ItemProperty -Path $existingFolder
        $childProperties = $childRegistry.psobject.properties
        
        foreach($property in $childProperties){
            Copy-ItemProperty -Path $existingFolder -Destination $newDestination -Name $property.Name
        }

        $message = "Copied properties from "+$names[$names.Count-1]
        Write-Output $message

        $subChildren = Get-ChildItem -Path $existingFolder
        addChildFolder ($subChildren) ($newDestination)
    }
}

if([string]::IsNullOrEmpty($SxSStackVersionName)){
    $SxSStackVersionName = "rdp-sxs"
}

#This is used for errors that should be ignored.
$ErrorActionPreference = "SilentlyContinue"

$destinationRegistry = "HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\"+$SxSStackVersionName

if(Test-Path "HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp"){
    
    #Create the new registery if it doesn't exist
    #If it exist then we will prompt user to uninstall the existing sxsstack for the given version.
    if(!(Test-Path $destinationRegistry)){
        New-Item -ItemType Directory -Force -Path $destinationRegistry
    
        $registryKey = Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp"
        $propertiesToBeCopied = $registryKey.psobject.properties

        #Assign all existing properties of RDP-Tcp to the new Registery except fEnableWinStation
        foreach ($property in $propertiesToBeCopied) {
            if($property.Name -ne "fEnableWinStation"){
                Copy-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp" -Destination $destinationRegistry -Name $property.Name
            }
            else{
                New-ItemProperty -Path $destinationRegistry -Name "fEnableWinStation" -Value 0
            }
        }

        $message = "Properties of RDP-Tcp are added to registery "+ $SxSStackVersionName
        Write-Output $message

        $rdpReverseConnectListener = "RDPRECCONNamedPipeServer_" + $SxSStackVersionName
        #Setting the extra properties neeeded
        New-ItemProperty -Path $destinationRegistry -Name "SxSStackType" -Value 3
        New-ItemProperty -Path $destinationRegistry -Name "ReverseConnectionPipeName" -Value $rdpReverseConnectListener

        $message = "Additional required key value pairs are added to "+ $SxSStackVersionName
        Write-Output $message

        $childFolders = Get-ChildItem -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp"
        addChildFolder ($childFolders) ($destinationRegistry)

        $message = "Child folders of RDP-Tcp are added to "+ $SxSStackVersionName
        Write-Output $message

        #Setting a listener on 1 level up.
        New-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations" -Name "ReverseConnectionListener" -Value $SxSStackVersionName
        
        $message = "Reverse connect listener for "+ $SxSStackVersionName+ " is added to WinStations"
        Write-Output $message


        #Change the parameter on fEnableWinStation to 1.
        Set-ItemProperty -Path $destinationRegistry -Name "fEnableWinStation" -Value 1

        $message = "Enabled WinStation for " + $SxSStackVersionName
        Write-Output $message

        # this needs to be done after the stack is activated
        Write-Output "Setting active listener for RedirectionInfo"
        New-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server\ClusterSettings" -Name "SessionDirectoryListener" -Value $SxSStackVersionName

        $qwinstaOutput = & "qwinsta" | Out-String
        Write-Output $qwinstaOutput
    }
    else{
        $qwinstaOutput = & "qwinsta" | Out-String
        Write-Output $qwinstaOutput
        $errorMessage = "The SxSStack you wish to enable "+ $SxSStackVersionName + " already exists either specify a new name with parameter -SxSStackVersionName or disable the existing version.An example with a parameter would be: .\enablesxsstackrc -SxSStackVersionName 'sxsrcstack'"
        Write-Error $errorMessage
    }
}
else{
    $qwinstaOutput = & "qwinsta" | Out-String
    Write-Output $qwinstaOutput
    $errorMessage = "Inbox SxSStack is not installed so cannot generate new SxSStackVersion please check your settings."
    Write-Error $errorMessage
}
