

#Deploy
New-AzureRmResourceGroupDeployment -Name "test1" `
    -ResourceGroupName "AZRDMIS16-RG" `
    -TemplateFile .\azuredeploy.json `
    -TemplateParameterFile .\azuredeploy.parameters.json `
    -Mode Incremental `
    -Verbose `
    -existingDomainUPN "SA-ITS-CVMS-JNJ@its.jnj.com" `
    -TenantAdminUPN "SA-ITS-CVMS-JNJ@its.jnj.com" `
    -existingTenantName "JnJ" `
    -imageId "/subscriptions/ac787c18-bfdd-46e2-824b-ca567f069426/resourceGroups/AZRDMIS16-RG/providers/Microsoft.Compute/images/RDMIBASEIMAGE01"

Need linked template for the following:
        "existingDomainPassword": {
            "reference": {
                "keyVault": {
                    "id": "/subscriptions/ac787c18-bfdd-46e2-824b-ca567f069426/resourceGroups/AZRDMIS16-RG/providers/Microsoft.KeyVault/vaults/RDMISecrets"
                },
                "secretName": "DomainJoinPW"
            },
            "metadata": {
                "notes": "Can use: DomainJoinPW"
            }
        },


        "TenantAdminPassword": {
            "reference": {
                "keyVault": {
                    "id": "/subscriptions/ac787c18-bfdd-46e2-824b-ca567f069426/resourceGroups/AZRDMIS16-RG/providers/Microsoft.KeyVault/vaults/RDMISecrets"
                },
                "secretName": "RDMITenantAdminPW"
            }
        },


        
    #Notes
<#
KeyVault Name: RDMISecrets
KeyVault RG Name: AZRDMIS16-RG
Secret Name for OU: RDMI-Pilot-OU
Secret Name: DomainJoinPW (we also have RDMITenantAdminPW)
UPN: SA-ITS-CVMS-JNJ@ITS.JNJ.COM

Loaded Image
------------
storage account name: rdmishstorage
resource group: RDmiSH
#>