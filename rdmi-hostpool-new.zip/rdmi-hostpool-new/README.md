# Create and provision new RDmi hostpool

This template updates RDSH servers in existing or new hostpool.

This template deploys the following resources:
+ `<rdshNumberOfInstances`> new virtual machines as RDSH servers


Note: Template does **not** delete or deallocate old RDSH instances, so you may still incur compute charges. These virtual machine instances may need to be deleted manually.

