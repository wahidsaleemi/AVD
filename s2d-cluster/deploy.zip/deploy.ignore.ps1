
#Wahid
Connect-AzureRmAccount -TenantId cb5cab0c-3dd6-4fb0-9de5-ce5c1bed68e7 -Verbose
Select-AzureRmSubscription -Subscription "VPCxAzureTeradatana"

Set-Location "C:\Users\wasaleem\Documents\jnjGit\azure-quickstart-templates\301-storage-spaces-direct"

$secPasswd = Read-Host "enter password" -AsSecureString
$rgName = "AZRDMIS16-RG"
#Deploy
Write-Verbose "Deploying to Azure..."

$deploymentName = "Wahid-" + ((Get-Date -Format s).Replace(":","-"))
If(!(Get-AzureRmResourceGroup -Name $rgName -errorAction SilentlyContinue)) {
    New-AzureRmResourceGroup -Location "southcentralus" -Name "AZRDMIS16-RG"
}
New-AzureRmResourceGroupDeployment -Name $deploymentName `
        -ResourceGroupName $rgName `
        -TemplateFile .\azuredeploy.json `
        -TemplateParameterFile .\azuredeploy.parameters.json `
        -Mode Incremental `
        -Verbose `
        -adminUsername "sa-service" `
        -existingDomainName "wahidsaleemi.net" `
        -oupath "OU=Computers,OU=Org1,DC=wahidsaleemi,DC=net" `
        -localAdminPassword (Get-Credential).Password

        <##>
removed following from parameters, any way to pass via Pwsh? Nope: https://github.com/Azure/azure-powershell/issues/3318
 "adminPassword": {
      "reference": {
        "keyVault": {
            "id": "/subscriptions/ac787c18-bfdd-46e2-824b-ca567f069426/resourceGroups/AZRDMIS16-RG/providers/Microsoft.KeyVault/vaults/RDMISecrets"
        },
        "secretName": "DomainJoinPW"
       }
      },
Probably need to use this: https://docs.microsoft.com/en-us/azure/azure-resource-manager/resource-manager-keyvault-parameter
#>

$vms = @("rdw-0","rdw-1","rds-1","rds-0")
foreach ($vm in $vms) {
    #VMs
    Remove-AzureRmResource -ResourceGroupName $rgName -ResourceType 'Microsoft.Compute/virtualMachines' -ResourceName $vm -Force -verbose -AsJob
 } 

 foreach ($vm in $vms) {
    #Disks
    $disk = $vm + "-osDisk"
    $nic = $vm + "-nic"
    Remove-AzureRmResource -ResourceGroupName $rgName -ResourceType 'Microsoft.Compute/disks' -ResourceName $disk -Force -verbose -AsJob
    Remove-AzureRmResource -ResourceGroupName $rgName -ResourceType 'Microsoft.Network/networkInterfaces' -ResourceName $nic -Force -verbose -AsJob
 } 
